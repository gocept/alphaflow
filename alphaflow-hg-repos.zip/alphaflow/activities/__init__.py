# Make this a python package
from Products.AlphaFlow.activities import \
    alarm, configuration, decision, expression, gates, notify, \
    ntask, routing, simpledecision, switch, termination
