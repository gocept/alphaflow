Workflow editor templates
=========================

The workflow editor features so called `templates` which can be used to
re-create more complex constructs in workflows reliably.

The examples shipped with AlphaFlow include:

- A time limited assignment

- A parallel review with configurable amount of reviews correctly wired up
  with routes and gates.
