=====================
Compatibility modules
=====================

factory.py
    taken from Zope 3.4's zope.annotation. Applied minor change to import to
    allow it to work with multiple Zope releases.

source.py
    taken from Zope 3.4's zope.app.form.browser. 
