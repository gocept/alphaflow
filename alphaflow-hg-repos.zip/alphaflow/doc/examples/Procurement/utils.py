# Copyright (c) 2004-2006 gocept. All rights reserved.
# See also LICENSE.txt
# $Id$

def getGroupFromAccount(account):
    return "account" + account
